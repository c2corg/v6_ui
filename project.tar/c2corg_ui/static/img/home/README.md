The images in this directory are used as backgrounds in the homepage.

They are provided courtesy of their authors with the following licences:
* `alexbuisse-greenland.jpg` by Alex Buisse http://www.alexbuisse.com/ under a Creative Commons By NC SA license (https://creativecommons.org/licenses/by-nc-sa/3.0/deed)
* `alexsaunier-monch.jpg` by Alex Saunier under a Creative Commons BY NC ND license (https://creativecommons.org/licenses/by-nc-nd/3.0/deed)
* `laurentf-sajama.jpg` by Laurent F http://lolofreg2.over-blog.com/ under a Creative Commons BY NC ND license (https://creativecommons.org/licenses/by-nc-nd/3.0/deed)
* `cermygian-crevasse.jpg` by cermygian https://www.camptocamp.org/profiles/279741/en under a Creative Commons By NC SA license (https://creativecommons.org/licenses/by-nc-sa/3.0/deed) Original image: https://www.camptocamp.org/images/566097/en/glacier-du-geant-m-blanc
