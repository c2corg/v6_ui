import angular from 'angular';
import ForumFeedController from './forum-feed.controller';

export default angular
  .module('c2c.forum-feed', [])
  .controller('ForumFeedController', ForumFeedController)
  .name;
