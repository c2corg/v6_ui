[b]Old bold BBcode en gras[/b] 
old [url=http://example.com]bbcode link[/url]

[[waypoints/12345/fr/some-slug|wiki link]] before [[/whatever|another one]] that follows.
Some **bold text** and *italic* and small <small>text</small>
*italic âccentuated content*
[markdown link](https://example.com?a=b&c=d)
Use the `printf()` function.
and <br> is allowed

<address@example.com>

[img=123]image[/img]

[video]http://www.youtube.com/watch?v=qEpdQDqaQdo[/video]

[video]wrong url[/video]

> quote

----

### lists

* Here
* is
    * a
* list

and

- Another
- list.

and

1. numbered list
* with autonumber

"Slope": > 30° and < 35°

Some pitches definition

L# | 5b | Nice slab with a slightly harder move
L# | 5a | Lightly protected, carrying a cam or two could help

> quote

    Code with <span>a span</span>
    Code with <patate>unknown tag</patate>

<script> alert("beach") </script> 

<span>span</span>

<patate>unknown tag</patate>

<iframe>iframe</iframe>

a est superieur > à b

This is [an example][id] reference-style link.

[id]: http://example.com/  "Optional Title Here"